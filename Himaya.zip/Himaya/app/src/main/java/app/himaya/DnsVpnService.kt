package app.himaya

import android.content.Intent
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.Settings
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

/**
 * Локальный «DNS-фильтр»: через VPN-интерфейс ловит только DNS-запросы телефона (остальной трафик идёт напрямую).
 * Плохой домен -> NXDOMAIN + экран с аятом. Остальное пересылается в Cloudflare Family (1.1.1.3),
 * а если он ответил 0.0.0.0 (домен в его базе взрослого контента) — тоже показываем экран.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val STOP = "app.himaya.STOP"
        @Volatile var isRunning = false
        private val UPSTREAM = listOf("1.1.1.3", "1.0.0.3")
    }

    private var tun: ParcelFileDescriptor? = null
    private var pool: ExecutorService? = null
    private var last = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val overlay by lazy { BlockOverlay(applicationContext) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { shutdown(); stopSelf(); return START_NOT_STICKY }
        start()
        return START_STICKY
    }

    override fun onRevoke() { shutdown(); super.onRevoke() }
    override fun onDestroy() { shutdown(); super.onDestroy() }

    private fun start() {
        if (isRunning) return
        val fd = Builder()
            .setSession("Himaya")
            .addAddress("10.111.222.1", 32)
            .addDnsServer("10.111.222.2")
            .addRoute("10.111.222.2", 32)
            .setBlocking(true)
            .establish()
        if (fd == null) { stopSelf(); return }
        tun = fd
        pool = Executors.newFixedThreadPool(8)
        isRunning = true
        Thread { loop(fd) }.start()
    }

    private fun shutdown() {
        isRunning = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        pool?.shutdownNow()
        pool = null
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (isRunning) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val pkt = buf.copyOf(n)
                pool?.execute { handle(pkt, output) }
            }
        } catch (e: Exception) { }
        if (isRunning) { shutdown(); stopSelf() }
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        try {
            if (p.size < 28 || (p[0].toInt() shr 4) != 4) return
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (p[9].toInt() != 17 || p.size < ihl + 8) return
            if (u16(p, ihl + 2) != 53) return
            val total = minOf(u16(p, 2), p.size)
            if (total < ihl + 8 + 12) return
            val reply = resolve(p.copyOfRange(ihl + 8, total)) ?: return
            val resp = buildPacket(p, ihl, reply)
            synchronized(out) { out.write(resp) }
        } catch (e: Exception) { }
    }

    private fun resolve(q: ByteArray): ByteArray? {
        var i = 12
        val sb = StringBuilder()
        while (i < q.size && q[i].toInt() != 0) {
            val l = q[i].toInt() and 0xFF
            if ((l and 0xC0) != 0 || i + 1 + l > q.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(q, i + 1, l, Charsets.US_ASCII))
            i += l + 1
        }
        val qEnd = i + 1 + 4
        if (qEnd > q.size) return null
        val name = sb.toString().lowercase()

        if (name in Blocklist.silent) return nxdomain(q, qEnd)
        if (Blocklist.isBlocked(name)) { notifyBlocked(); return nxdomain(q, qEnd) }

        val r = forward(q) ?: return null
        if (upstreamBlocked(r)) notifyBlocked()
        return r
    }

    private fun nxdomain(q: ByteArray, end: Int): ByteArray {
        val r = q.copyOf(end)
        r[2] = (0x80 or (q[2].toInt() and 0x01)).toByte() // QR=1, RD как в запросе
        r[3] = 0x83.toByte()                               // RA + NXDOMAIN
        for (k in 6..11) r[k] = 0                          // ни ответов, ни доп. секций
        return r
    }

    private fun forward(q: ByteArray): ByteArray? {
        for (host in UPSTREAM) {
            try {
                return DatagramSocket().use { s ->
                    protect(s)
                    s.soTimeout = 3000
                    s.send(DatagramPacket(q, q.size, InetAddress.getByName(host), 53))
                    val buf = ByteArray(4096)
                    val rp = DatagramPacket(buf, buf.size)
                    s.receive(rp)
                    buf.copyOf(rp.length)
                }
            } catch (e: Exception) { }
        }
        return null
    }

    private fun skipName(b: ByteArray, start: Int): Int {
        var i = start
        while (true) {
            val l = b[i].toInt() and 0xFF
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return i + 2
            i += l + 1
        }
    }

    /** Cloudflare Family отвечает 0.0.0.0 / :: на домены из своей базы 18+. */
    private fun upstreamBlocked(r: ByteArray): Boolean {
        try {
            if (r.size < 12 || (r[3].toInt() and 0x0F) != 0) return false
            var i = 12
            repeat(u16(r, 4)) { i = skipName(r, i) + 4 }
            repeat(u16(r, 6)) {
                i = skipName(r, i)
                val type = u16(r, i)
                val len = u16(r, i + 8)
                val d = i + 10
                if ((type == 1 && len == 4) || (type == 28 && len == 16)) {
                    if ((d until d + len).all { r[it].toInt() == 0 }) return true
                }
                i = d + len
            }
        } catch (e: Exception) { }
        return false
    }

    private fun notifyBlocked() {
        val now = System.currentTimeMillis()
        synchronized(this) {
            if (now - last < 4000) return
            last = now
            val p = getSharedPreferences("himaya", MODE_PRIVATE)
            p.edit().putInt("count", p.getInt("count", 0) + 1).apply()
        }
        if (Settings.canDrawOverlays(this)) handler.post { overlay.show() }
    }

    private fun buildPacket(req: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val len = 28 + payload.size
        val o = ByteArray(len)
        o[0] = 0x45
        o[2] = (len shr 8).toByte(); o[3] = len.toByte()
        o[8] = 64; o[9] = 17
        System.arraycopy(req, 16, o, 12, 4) // источник = бывший получатель
        System.arraycopy(req, 12, o, 16, 4) // получатель = бывший источник
        var sum = 0
        for (k in 0 until 20 step 2) sum += ((o[k].toInt() and 0xFF) shl 8) or (o[k + 1].toInt() and 0xFF)
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val ck = sum.inv() and 0xFFFF
        o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()
        System.arraycopy(req, ihl + 2, o, 20, 2) // порт источника = 53
        System.arraycopy(req, ihl, o, 22, 2)     // порт получателя
        val ul = 8 + payload.size
        o[24] = (ul shr 8).toByte(); o[25] = ul.toByte()
        System.arraycopy(payload, 0, o, 28, payload.size)
        return o
    }
}
