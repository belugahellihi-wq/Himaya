package app.himaya

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val gold = Color.parseColor("#D4AF37")
    private lateinit var ring: TextView
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var perm: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(t: String, sp: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun LinearLayout.put(v: View, top: Int = 0) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bg = Color.parseColor("#0B1F1A")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        ring = label("", 28f, Color.WHITE, true).apply {
            minWidth = dp(200); minHeight = dp(200)
            setOnClickListener { onTap() }
            setOnLongClickListener { onHold(); true }
        }
        status = label("", 16f, Color.WHITE)
        stats = label("", 14f, Color.parseColor("#9FB8AE"))
        perm = label("⚠ Разреши показ поверх других окон — без этого аяты не появятся. Нажми сюда.", 14f, Color.parseColor("#FFB4A8")).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.parseColor("#E5484D")) }
            setOnClickListener { openOverlaySettings() }
        }
        val test = label("Посмотреть экран блокировки", 14f, gold).apply {
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) BlockOverlay(applicationContext).show()
                else openOverlaySettings()
            }
        }
        val tip = label("Совет: Настройки → Сеть → Частный DNS → «Автоматически» или «Выкл», иначе защиту можно обойти. Для автозапуска после перезагрузки включи в настройках VPN → Himaya → «Постоянная VPN».", 12f, Color.parseColor("#6E8A7F"))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(bg)
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }
        root.put(label("حماية", 52f, gold, true))
        root.put(label("Himaya · щит для твоего взгляда", 14f, Color.parseColor("#9FB8AE")), 4)
        root.put(ring, 48)
        root.put(status, 20)
        root.put(stats, 6)
        root.put(perm, 28)
        root.put(test, 28)
        root.put(tip, 28)
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(root) })
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        val on = DnsVpnService.isRunning
        ring.text = if (on) "ВКЛ" else "ВЫКЛ"
        ring.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(if (on) "#14684A" else "#16231F"))
            setStroke(dp(4), if (on) gold else Color.parseColor("#33463F"))
        }
        status.text = if (on) "Защита активна\nудерживай кнопку, чтобы выключить" else "Нажми, чтобы включить"
        val n = getSharedPreferences("himaya", MODE_PRIVATE).getInt("count", 0)
        stats.text = "Закрыто сайтов: $n"
        perm.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
    }

    private fun onTap() {
        if (DnsVpnService.isRunning) {
            Toast.makeText(this, "Удерживай кнопку, чтобы выключить", Toast.LENGTH_SHORT).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return }
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 1) else startVpn()
    }

    private fun onHold() {
        if (!DnsVpnService.isRunning) return
        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.STOP))
        ring.postDelayed({ render() }, 400)
    }

    private fun startVpn() {
        startService(Intent(this, DnsVpnService::class.java))
        ring.postDelayed({ render() }, 500)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) startVpn()
    }
}
